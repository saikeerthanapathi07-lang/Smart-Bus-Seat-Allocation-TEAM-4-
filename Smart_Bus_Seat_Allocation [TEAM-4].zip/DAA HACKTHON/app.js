const busData = [
  {
    id: 'TS09AB1234',
    route: 'Hyderabad → Karimnagar',
    type: 'Executive Sleeper',
    departure: '08:30',
    arrival: '11:45',
    totalSeats: 40,
    fare: 750,
    occupancy: 70,
    availableSeats: 12,
    seats: generateSeats(40, 0.7)
  },
  {
    id: 'TS09CD5678',
    route: 'Hyderabad → Warangal',
    type: 'Premium AC',
    departure: '09:15',
    arrival: '12:40',
    totalSeats: 40,
    fare: 680,
    occupancy: 62,
    availableSeats: 15,
    seats: generateSeats(40, 0.62)
  },
  {
    id: 'TS19EF9911',
    route: 'Secunderabad → Nizamabad',
    type: 'City Deluxe',
    departure: '10:45',
    arrival: '14:15',
    totalSeats: 40,
    fare: 620,
    occupancy: 75,
    availableSeats: 10,
    seats: generateSeats(40, 0.75)
  }
];

const state = {
  selectedBusId: 'TS09AB1234',
  selectedSeat: null,
  bookingConfirmed: false,
  demoMode: false,
  recommendation: null
};

const seatMap = document.getElementById('seat-map');
const busList = document.getElementById('bus-list');
const recommendedSeatEl = document.getElementById('recommendedSeat');
const matchScoreEl = document.getElementById('matchScore');
const reasonListEl = document.getElementById('reasonList');
const seatDetailContent = document.getElementById('seat-detail-content');
const busSelect = document.getElementById('busSelect');
const demoLog = document.getElementById('demoLog');

function generateSeats(totalSeats, occupancyRate) {
  const seats = [];
  const occupiedCount = Math.round(totalSeats * occupancyRate);
  const letters = ['A', 'B', 'C', 'D'];

  for (let row = 1; row <= totalSeats / 4; row += 1) {
    letters.forEach((letter) => {
      const id = `${row}${letter}`;
      const isOccupied = seats.length < occupiedCount && Math.random() > 0.22;
      const isPriority = row % 5 === 0 && letter === 'A';
      seats.push({
        id,
        row,
        letter,
        status: isOccupied ? 'occupied' : 'available',
        passenger: isOccupied ? pickPassenger(row) : '',
        accessibility: row <= 2 && letter === 'A',
        reserved: isPriority,
        score: 0
      });
    });
  }

  return seats;
}

function pickPassenger(row) {
  const names = ['Ananya', 'Rahul', 'Priya', 'Kiran', 'Suresh', 'Asha', 'Mohan', 'Neha'];
  return names[(row + names.length) % names.length];
}

function getSelectedBus() {
  return busData.find((bus) => bus.id === state.selectedBusId) || busData[0];
}

function getSeatById(seatId) {
  return getSelectedBus().seats.find((seat) => seat.id === seatId);
}

function renderBusCards() {
  busList.innerHTML = '';

  busData.forEach((bus) => {
    const card = document.createElement('article');
    card.className = `bus-card${bus.id === state.selectedBusId ? ' selected' : ''}`;
    card.innerHTML = `
      <div class="bus-meta">
        <h3>${bus.id}</h3>
        <p>${bus.route}</p>
        <div class="bus-metrics">
          <span>Departure ${bus.departure}</span>
          <span>Arrival ${bus.arrival}</span>
          <span>Fare ₹${bus.fare}</span>
        </div>
      </div>
      <button class="btn btn-secondary select-bus-btn" type="button" data-bus-id="${bus.id}">Select Bus</button>
    `;

    const button = card.querySelector('button');
    button.addEventListener('click', () => {
      state.selectedBusId = bus.id;
      state.selectedSeat = null;
      busSelect.value = bus.id;
      renderBusCards();
      renderSeatMap();
      updateRecommendation();
      showToast(`${bus.id} selected. Ready to allocate a smart seat.`, 'info');
    });

    busList.appendChild(card);
  });
}

function renderSeatMap() {
  const bus = getSelectedBus();
  seatMap.innerHTML = '';

  bus.seats.forEach((seat) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `seat-map-seat ${seat.status}`;
    button.textContent = seat.id;
    button.setAttribute('aria-label', `Seat ${seat.id}, ${seat.status}`);

    if (seat.id === state.selectedSeat) {
      button.classList.add('selected');
    }

    button.addEventListener('click', () => {
      state.selectedSeat = seat.id;
      renderSeatMap();
      renderSeatDetails(seat.id);
      showToast(`Seat ${seat.id} selected. Checking compatibility.`, 'info');
    });

    seatMap.appendChild(button);
  });
}

function renderSeatDetails(seatId) {
  const seat = getSeatById(seatId);

  if (!seat) {
    seatDetailContent.innerHTML = '<p class="seat-empty-state">Select a seat to inspect its status and compatibility.</p>';
    return;
  }

  const isWindow = ['A', 'D'].includes(seat.letter);
  const isFront = seat.row <= 3;
  const info = state.recommendation && state.recommendation.seatId === seat.id ? state.recommendation : null;

  seatDetailContent.innerHTML = `
    <div class="seat-key">${seat.id}</div>
    <div><strong>Window/Aisle:</strong> ${isWindow ? 'Window' : 'Aisle'}</div>
    <div><strong>Status:</strong> ${capitalize(seat.status)}</div>
    <div><strong>Passenger:</strong> ${seat.passenger || 'Open seat'}</div>
    <div><strong>Location:</strong> ${isFront ? 'Front' : seat.row <= 7 ? 'Middle' : 'Back'}</div>
    <div><strong>Preference compatibility:</strong> ${info ? 'High match' : 'Pending review'}</div>
    <div><strong>Allocation score:</strong> ${info ? `${info.score}%` : '—'}</div>
  `;
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function getSeatFeatureScore(seat, preferences) {
  let score = 0;

  if (preferences.position === 'Window' && ['A', 'D'].includes(seat.letter)) score += 35;
  if (preferences.position === 'Aisle' && ['B', 'C'].includes(seat.letter)) score += 30;
  if (preferences.position === 'Any') score += 12;

  if (preferences.location === 'Front' && seat.row <= 3) score += 22;
  if (preferences.location === 'Middle' && seat.row > 3 && seat.row <= 7) score += 18;
  if (preferences.location === 'Back' && seat.row > 7) score += 18;
  if (preferences.location === 'Any') score += 10;

  if (preferences.lowerSeat && seat.row <= 2) score += 18;
  if (preferences.awayFromDoor && seat.row > 1) score += 12;
  if (preferences.nearFamily && seat.row <= 4) score += 8;
  if (preferences.accessibility) {
    if (seat.row <= 3 && ['A', 'D'].includes(seat.letter)) score += 28;
    else score += 10;
  }

  if (seat.reserved) score += 14;
  if (seat.id === '12A' || seat.id === '13A') score += 6;

  const seatGapPenalty = seat.row > 1 && seat.row < 10 && ((seat.row + 1) % 3 === 0) ? 10 : 0;
  score -= seatGapPenalty;

  if (preferences.priority === 'Senior Citizen') score += 18;
  if (preferences.priority === 'Person with Accessibility Requirement') score += 24;
  if (preferences.priority === 'Family/Group Booking') score += 16;

  return Math.max(score, 0);
}

function buildPreferenceState() {
  return {
    position: document.getElementById('seatPosition').value,
    location: document.getElementById('seatLocation').value,
    priority: document.getElementById('priorityLevel').value,
    lowerSeat: document.getElementById('lowerSeat').checked,
    awayFromDoor: document.getElementById('awayFromDoor').checked,
    nearFamily: document.getElementById('nearFamily').checked,
    accessibility: document.getElementById('accessibilityReq').checked,
    noPreference: document.getElementById('noPreference').checked
  };
}

function getSeatRecommendation() {
  const bus = getSelectedBus();
  const preferences = buildPreferenceState();
  const preferredSeat = determinePreferredSeat(preferences, bus);
  let bestSeat = null;
  let bestScore = -Infinity;

  bus.seats.forEach((seat) => {
    if (seat.status === 'occupied') return;

    if (preferences.accessibility && !seat.accessibility && !['A', 'D'].includes(seat.letter)) {
      return;
    }

    const score = getSeatFeatureScore(seat, preferences) + (seat.isPreferred ? 10 : 0);
    if (seat.id === preferredSeat && seat.status === 'available') {
      seat.score = score + 10;
    } else {
      seat.score = score;
    }

    if (seat.score > bestScore) {
      bestScore = seat.score;
      bestSeat = seat;
    }
  });

  if (!bestSeat) {
    return {
      seatId: 'No seat available',
      score: 0,
      reasons: ['No suitable seat is currently available.'],
      preferredSeat: preferredSeat || 'N/A'
    };
  }

  const reasons = [
    `${preferences.position === 'Window' ? 'Window preference matched' : 'Balanced seat selection applied'}`,
    `${preferences.location === 'Front' ? 'Preferred front section' : 'Good placement for occupancy balance'}`,
    'Suitable for passenger priority',
    'Helps reduce empty seat gaps'
  ];

  if (bestSeat.id !== preferredSeat && preferredSeat) {
    reasons.unshift(`Your preferred seat is unavailable. We found the closest suitable alternative.`);
  }

  return {
    seatId: bestSeat.id,
    score: Math.min(Math.max(Math.round(bestScore), 60), 98),
    reasons,
    preferredSeat,
    alternative: bestSeat.id !== preferredSeat && preferredSeat
  };
}

function determinePreferredSeat(preferences, bus) {
  if (preferences.position === 'Window') {
    const windowSeats = bus.seats.filter((seat) => ['A', 'D'].includes(seat.letter) && seat.status === 'available');
    return windowSeats[0]?.id || '12A';
  }

  if (preferences.location === 'Front') {
    const frontSeats = bus.seats.filter((seat) => seat.row <= 3 && seat.status === 'available');
    return frontSeats[0]?.id || '12A';
  }

  return '12A';
}

function updateRecommendation() {
  const recommendation = getSeatRecommendation();
  state.recommendation = recommendation;

  recommendedSeatEl.textContent = recommendation.seatId;
  matchScoreEl.textContent = `${recommendation.score}%`;
  reasonListEl.innerHTML = recommendation.reasons
    .map((reason) => `<li>✓ ${reason}</li>`)
    .join('');

  if (recommendation.alternative) {
    showToast(`Your preferred seat is unavailable. We found the closest suitable alternative.`, 'warning');
  }
}

function applyBusSelection(busId) {
  state.selectedBusId = busId;
  state.selectedSeat = null;
  busSelect.value = busId;
  renderBusCards();
  renderSeatMap();
  updateRecommendation();
}

function handleGlobalButtonClick(event) {
  const actionTarget = event.target.closest('[data-action]');
  if (actionTarget) {
    const action = actionTarget.dataset.action;

    if (action === 'login') {
      showToast('Login flow is ready for your next integration.', 'info');
      return;
    }

    if (action === 'signup') {
      showToast('Signup flow is ready for your next integration.', 'success');
      return;
    }
  }

  const targetButton = event.target.closest('[data-scroll]');
  if (targetButton) {
    const targetId = targetButton.dataset.scroll;
    const target = document.querySelector(targetId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    return;
  }

  const busButton = event.target.closest('[data-bus-id]');
  if (busButton) {
    applyBusSelection(busButton.dataset.busId);
    showToast(`${busButton.dataset.busId} selected. Ready to allocate a smart seat.`, 'info');
    return;
  }

  if (event.target.closest('#acceptSeatBtn')) {
    const recommendation = state.recommendation;
    if (!recommendation) return;

    const seat = getSeatById(recommendation.seatId);
    if (seat) {
      seat.status = 'occupied';
      seat.passenger = document.getElementById('passengerName').value || 'Passenger';
      state.bookingConfirmed = true;
      renderSeatMap();
      renderSeatDetails(recommendation.seatId);
      showToast('Booking successful. Seat allocated and confirmed.', 'success');
      updateConfirmationSummary();
    }
    return;
  }

  if (event.target.closest('#otherOptionsBtn')) {
    const bus = getSelectedBus();
    const alternatives = bus.seats.filter((seat) => seat.status === 'available').slice(0, 4);
    if (!alternatives.length) {
      showToast('No alternative seats are currently available.', 'warning');
      return;
    }
    const altText = alternatives.map((seat) => seat.id).join(', ');
    showToast(`Other options: ${altText}`, 'info');
    return;
  }

  if (event.target.closest('#changePrefsBtn')) {
    document.getElementById('preferences').scrollIntoView({ behavior: 'smooth', block: 'start' });
    showToast('Adjust your preferences to refine the recommendation.', 'info');
    return;
  }

  if (event.target.closest('#demoModeBtn')) {
    runDemoMode();
  }
}

function addEventListeners() {
  busSelect.addEventListener('change', (event) => {
    state.selectedBusId = event.target.value;
    state.selectedSeat = null;
    renderBusCards();
    renderSeatMap();
    updateRecommendation();
  });

  document.getElementById('seatPosition').addEventListener('change', updateRecommendation);
  document.getElementById('seatLocation').addEventListener('change', updateRecommendation);
  document.getElementById('priorityLevel').addEventListener('change', updateRecommendation);
  document.getElementById('lowerSeat').addEventListener('change', updateRecommendation);
  document.getElementById('awayFromDoor').addEventListener('change', updateRecommendation);
  document.getElementById('nearFamily').addEventListener('change', updateRecommendation);
  document.getElementById('accessibilityReq').addEventListener('change', updateRecommendation);
  document.getElementById('noPreference').addEventListener('change', updateRecommendation);

  document.addEventListener('click', handleGlobalButtonClick);
}

function runDemoMode() {
  state.demoMode = true;
  const steps = [
    'Analyzing 12 available seats...',
    'Checking preferences...',
    'Checking booking priority...',
    'Optimizing occupancy...',
    'Best seat found: 12A'
  ];

  const stepEls = [...demoLog.children];
  stepEls.forEach((el) => el.classList.remove('active'));

  steps.forEach((step, index) => {
    setTimeout(() => {
      stepEls.forEach((el) => el.classList.remove('active'));
      if (stepEls[index]) {
        stepEls[index].classList.add('active');
      }
    }, index * 800);
  });

  setTimeout(() => {
    showToast('Demo mode activated. Best seat found: 12A', 'success');
    recommendedSeatEl.textContent = '12A';
    matchScoreEl.textContent = '94%';
    reasonListEl.innerHTML = `
      <li>✓ Window preference matched</li>
      <li>✓ Preferred front section</li>
      <li>✓ Suitable for passenger priority</li>
      <li>✓ Helps reduce empty seat gaps</li>
    `;
  }, 3200);
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.getElementById('toast-container').appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 2600);
}

function updateConfirmationSummary() {
  const summary = `
    <div class="seat-key">✓ Booking Confirmed</div>
    <div><strong>Passenger:</strong> ${document.getElementById('passengerName').value}</div>
    <div><strong>Bus:</strong> ${getSelectedBus().id}</div>
    <div><strong>Route:</strong> ${getSelectedBus().route}</div>
    <div><strong>Date:</strong> ${document.getElementById('travelDate').value || '15 October 2026'}</div>
    <div><strong>Seat:</strong> ${state.recommendation?.seatId || '12A'}</div>
    <div><strong>Seat Type:</strong> Window</div>
    <div><strong>Allocation Match:</strong> ${state.recommendation?.score || '94'}%</div>
    <p class="seat-empty-state">Your seat was intelligently selected based on your preferences and current bus occupancy.</p>
  `;

  seatDetailContent.innerHTML = summary;
}

function initialize() {
  window.scrollTo(0, 0);
  renderBusCards();
  renderSeatMap();
  renderSeatDetails('12A');
  updateRecommendation();
  addEventListeners();
  busSelect.value = state.selectedBusId;
}

initialize();
